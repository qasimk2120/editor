import User from "../models/User.js";
export const getFileData = async (req, res, next) => {
  try {
    const { filename, objectKey, userId, lastModified, fileType } = req.body;
    // Find the user
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found." });
    }

    // Create a new file document
    const file = {
      objectKey,
      filename,
      lastModified,
      fileType,
    };

    // Determine the appropriate array
    const filesArray = fileType === "pdf" ? user.pdfs : user.photos;

    // Check if a file with the same objectKey already exists
    const existingFileIndex = filesArray.findIndex(
      (f) => f.objectKey === objectKey,
    );

    if (existingFileIndex !== -1) {
      // If the file exists, update it
      filesArray[existingFileIndex] = file;
    } else {
      // If the file doesn't exist, add it
      filesArray.push(file);
    }

    // Save the user document
    await user.save();

    // Send a success response
    res.status(200).json({ message: "File information stored successfully." });
  } catch (error) {
    next(error);
  }
};

export const getUserFiles = async (req, res, next) => {
  try {
    const { userId } = req.body; // Get the userId from the request body
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found." });
    }

    const files = [...user.pdfs, ...user.photos];
    res.status(200).json(files);
  } catch (error) {
    next(error);
  }
};

export const deleteUserFile = async (req, res, next) => {
  try {
    const { userId, objectKey } = req.body;
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found." });
    }

    // If the file exists in pdfs, remove it
    user.pdfs.pull({ objectKey: objectKey });

    // If the file exists in photos, remove it
    user.photos.pull({ objectKey: objectKey });

    // Save the user document
    await user.save();

    // Send a success response
    res.status(200).json({ message: "File information deleted successfully." });
  } catch (error) {
    console.log(error)
    next(error);
  }
};

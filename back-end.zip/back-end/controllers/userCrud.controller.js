import User from "../models/User.js";
import {CreateError} from "../utils/error.js";
import {CreateSuccess} from "../utils/success.js";

export const getUserById = async (req, res, next) => {
    try {
        console.log(`Fetching user with ID ${req.params.id}...`); // Add a log before fetching a user
        const user = await User.findById(req.params.id).populate('roles');
        if (!user) {
            return next(CreateError(404, 'User not found'));
        } else {
            console.log(`Found user with ID ${req.params.id}`); // Add a log after successfully fetching a user
            return next(CreateSuccess(200, 'User Found, User details :' ,user));
        }
    } catch (error) {
        console.error(`Error fetching user with ID ${req.params.id}: ${error}`); // Add a log when an error occurs
        return next(CreateError(500, 'Internal Server Error' + error.message));
    }
};

export const updateUser = async (req, res, next) => {
    try {
        console.log(`Updating user with ID ${req.params.id}...`); // Add a log before updating a user
        const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!user) {
            return next(CreateError(404, 'User not found'));
        } else {
            console.log(`Updated user with ID ${req.params.id}`); // Add a log after successfully updating a user
            return next(CreateSuccess(200, 'User updated successfully', user));
        }
    } catch (error) {
        console.error(`Error updating user with ID ${req.params.id}: ${error}`); // Add a log when an error occurs
        return next(CreateError(500, 'Internal Server Error' + error.message));
    }
};

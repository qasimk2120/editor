import Role from "../models/Role.js";
import User from "../models/User.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import nodemailer from "nodemailer";
import UserToken from "../models/UserToken.js";
import { CreateError } from "../utils/error.js";
import { CreateSuccess } from "../utils/success.js";
import http from "http";
//-------------------------------------------------------------------------------------------------------------\\

// Function to check if user already exists either by username or email
const checkExistingUser = async (userName, email) => {
  return User.findOne({
    $or: [{ userName: userName }, { email: email }],
  });
};


//-------------------------------------------------------------------------------------------------------------\\
//User Registration Function along with request handlers
export const register = async (req, res, next) => {
  const existingUser = await checkExistingUser(
    req.body.userName,
    req.body.email,
  );
  // checking if user already exists either by username or email inside registration request
  if (existingUser) {
    if (existingUser.userName === req.body.userName) {
      return next(CreateError(403, "Username is already in use"));
    }
    if (existingUser.email === req.body.email) {
      return next(CreateError(403, "Email is already in use"));
    }
  }
  //using bcrypt here in Auth for hashing the password
  const role = await Role.find({ role: "User" });
  const hashPassword = await bcrypt.hash(req.body.password, 12);
  const newUser = new User({
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    userName: req.body.userName,
    email: req.body.email,
    password: hashPassword,
    roles: role,
  });
  await newUser.save();
  return next(CreateSuccess(200, "User Registered Successfully"));
};

//-------------------------------------------------------------------------------------------------------------\\
//LOGIN function along with request handlers
export const login = async (req, res, next) => {
  try {
    //Getting the user role reference here on .populate from the User.js database  along with first finding the user email on User.js database
    const user = await User.findOne({ email: req.body.email }).populate(
      "roles",
      "role",
    );
    if (!user) {
      return next(CreateError(401, "User not found"));
    }
    //destructing
    const { roles } = user;
    //comparing the Entered Password and the database password
    const isPasswordCorrect = await bcrypt.compare(
      req.body.password,
      user.password,
    );
    if (!isPasswordCorrect) {
      return next(CreateError(401, "Password incorrect"));
    }
    //Creaing JWT token
    const token = jwt.sign(
      { id: user._id, isAdmin: user.isAdmin, roles: roles },
      process.env.JWT_SECRET,
    );
    const expirationDate = new Date();
    expirationDate.setDate(expirationDate.getDate() + 1);
    //Sending cookie on successful login to the client side
    res
      .cookie("access_token", token, {
        expires: expirationDate,
        httpOnly: true,
      })
      .status(200)
      .json({
        status: 200,
        message: "Login Success",
        data: user,
      });
  } catch (err) {
    return next(CreateError(500, "Something went wrong"));
  }
};

//-------------------------------------------------------------------------------------------------------------\\
//Forgot Password Implementation

export const sendEmail = async (req, res, next) => {
  const email = req.body.email;

  const user = await User.findOne({
    email: { $regex: "^" + email + "$", $options: "i" },
  });

  if (!user) {
    return next(
      CreateError(
        404,
        "User Not Found, Please Ensure that You enter a valid Email",
      ),
    );
  }

  const payload = { email: user.email };
  const expiryTime = 300;
  const token = jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: expiryTime,
  });

  const newToken = new UserToken({
    userId: user._id,
    token: token,
  });

  const mainTransporter = nodemailer.createTransport({
    service: process.env.MAIN_SERVICE,
    auth: {
      user: process.env.ADMIN_MAIL_EMAIL,
      pass: process.env.ADMIN_MAIL_PASS,
    },
  });
  const resetLink = `${process.env.LIVE_URL}/reset/${token}`;

  let mailDetails = {
    from: process.env.ADMIN_MAIL_EMAIL,
    to: email,
    subject: "Reset Password!",
    html: `<html>
    <head>
        <title>Password Reset Request </title>
    </head>
    <body>
        <h1>Password Reset Request</h1>
        <p>Dear ${user.userName},</p>
        <p> We have received a request to reset your password for your account with EditMasters. To Complete the password reset process, please click on the button below : </p>
        <a href="${resetLink}"><button style="background-color: #4CAF50 ; color: white; padding: 14px 20px; border: none; cursor: pointer; border-radius: 4px;">Reset Password</button></a>
        <p>Please note that this link is only valid for 5 mins. If you did not request a password reset, please disregard this message.</p>
        <p>Thank you,Edit Masters Team</p>
    </body> 
    </html>`,
  };

  //----------------------------------------------------------------------------
  //sending email

  mainTransporter.sendMail(mailDetails, async (err, data) => {
    if (err) {
      return next(CreateError(500, "Something went wrong while sending mail"));
    } else {
      //Email Sent Successfully
      await newToken.save();
      //Token saved to database untill expiration
      return next(
        CreateSuccess(
          200,
          "Email was Sent Successfully, Please Check your Inbox",
        ),
      );
    }
  });
};

//-------------------------------------------------------------------------------------------------------------\\

//UPDATING the password in the backend and database
export const resetPassword = (req, res, next) => {
  const token = req.body.token;
  const newPassword = req.body.newPassword;

  jwt.verify(token, process.env.JWT_SECRET, async (err, data) => {
    if (err) {
      return next(CreateError(401, "Reset Link Expired"));
    } else {
      const response = data;
      const user = await User.findOne({
        email: { $regex: "^" + response.email + "$", $options: "i" },
      });
      if (!newPassword) {
        return next(CreateError(400, "New password is required"));
      }
      const encryptedPassword = await bcrypt.hash(newPassword, 12);
      user.password = encryptedPassword;
      try {
        const updatedUser = await User.findOneAndUpdate(
          { _id: user._id },
          { $set: user },
          { new: true },
        );
        return next(CreateSuccess(200, "Successfully updated the password"));
      } catch (err) {
        return next(CreateError(200, "Error updating the password"));
      }
    }
  });
};

//-------------------------------------------------------------------------------------------------------------\\

export const logout = async (req, res) => {
  try {
    // Clear the HttpOnly cookie
    res.clearCookie("access_token");

    // Revoke the Google access token (if available)
    const googleAccessToken = req.cookies.access_token; // Assuming you store the access token in a cookie
    if (googleAccessToken) {
      // Make an HTTP request to Google's token revocation endpoint
      const revokeUrl = `https://accounts.google.com/o/oauth2/revoke?token=${googleAccessToken}`;
      http.get(revokeUrl, (response) => {
        console.log("Google token revoked successfully", response);
        return next(CreateSuccess(200, "Successfully revoked the cookie"));
      });
    }
    // Send a success response
    res.status(200).json(CreateSuccess(200, "Logged out", null));
  } catch (error) {
    console.error(error);
    return next(CreateError(500, "Something went wrong"));
  }
};

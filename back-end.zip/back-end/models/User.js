import mongoose from 'mongoose';

const PdfSchema = new mongoose.Schema({
    objectKey: { type: String, required: true },
    filename: { type: String, required: true },
    lastModified: { type: Date, default: Date.now, required: true },
    fileType: { type: String, required: true },
});

const PhotoSchema = new mongoose.Schema({
    objectKey: { type: String, required: true },
    filename: { type: String, required: true },
    lastModified: { type: Date, default: Date.now, required: true },
    fileType: { type: String, required: true },
});

const UserSchema = new mongoose.Schema(
    {
        firstName: {
            type: String,
            required: true,
        },
        lastName: {
            type: String,
            required: true,
        },
        isActive: {
            type: Boolean,
            default: true,
        },
        userName: {
            type: String,
            required: true,
            unique: false,
        },
        email: {
            type: String,
            required: true,
            unique: true,
        },
        password: {
            type: String,
            required: false,
        },
        profileImage: {
            type: String,
            required: false,
            default:
                "https://th.bing.com/th/id/OIP.i_bpSvfG5T2Ekf3xGuqQMwHaH_?rs=1&pid=ImgDetMain",
        },
        isAdmin: {
            type: Boolean,
            default: false,
        },
        roles: {
            type: [mongoose.Schema.Types.ObjectId],
            required: true,
            ref: "Role",
        },
        pdfs: [PdfSchema],
        photos: [PhotoSchema],
    },
    {
        timestamps: true,
    },
);

export default mongoose.model("User", UserSchema);

import express from 'express';
import {
  register,
  login,
  sendEmail,
  resetPassword,
    logout
} from '../controllers/auth.controller.js';
const router = express.Router();
//register endpoint
router.post('/register', register);
//login endpoint
router.post('/login', login);
//logout endpoint
router.post('/logout', logout);


//Sending Email for password recovery
router.post('/send-email', sendEmail);

//Resetting password inside the database
router.post('/reset-password', resetPassword);
export default router;

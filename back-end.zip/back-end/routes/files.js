import express from "express";
import {
  deleteUserFile,
  getFileData,
  getUserFiles,
} from "../controllers/file.controller.js";
//----------------------------------------------------------------------------

// Routes for Sending and getting PDF files from and to the User
const router = express.Router();
router.post("/get-filedata", getFileData); //Route to store uploaded files in AWS
router.post("/files", getUserFiles);
router.post("/delete-file", deleteUserFile);

//----------------------------------------------------------------------------
export default router;

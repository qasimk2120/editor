import express from "express";
import { getUserById, updateUser } from "../controllers/userCrud.controller.js";
import { verifyUser } from "../utils/verifyToken.js";
const router = express.Router();

//route for getting user profile    /api/crud/:id
router.get("/:id", verifyUser, getUserById);
router.put("/:id", verifyUser, updateUser);
export default router;
